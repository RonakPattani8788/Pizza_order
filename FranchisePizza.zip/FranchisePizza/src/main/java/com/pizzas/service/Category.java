package com.pizzas.service;

public interface Category {
	String Classic_Category="Classic";
	String Premium_Category="Premium";
	String Supreme_category="Supreme";
}
