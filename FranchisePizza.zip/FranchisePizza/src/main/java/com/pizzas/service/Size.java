package com.pizzas.service;

public interface Size {
	String Regular_size="Regular-size";
	String Medium_size="Medium-size";
	String Large_size="Large-Size";
}
