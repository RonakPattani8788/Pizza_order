package com.pizzas.service;

public interface PizzaMenu {
	String Tomchi_Pizza = "Tomchi";
	String Caponito_Pizza = "Caponito";
	String Red_Indian_Pizza = "Red_Indian";
	String Party_Lovers_Pizza = "Party_Lovers";
	String American_Heat_Pizza = "American_Heat";
	String Re_Union_Pizza = "Re_Union";
}
