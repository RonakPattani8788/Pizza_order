package com.pizzas.service;

public interface Cuisine {
	String Regular_Cuisine="Regular";
	String Jain_Cuisine="Jain";
	String Non_Veg_Cuisine="Non_veg";
}
