package com.pizzas;

import java.util.Scanner;

import com.pizzas.cuisine.Pizza;
import com.pizzas.cuisine.Prize;
import com.pizzas.cuisine.Order;
import com.pizzas.cuisine.CuisineImpl;
import com.pizzas.cuisine.SizeImpl;
import com.pizzas.cuisine.Toppings;
import com.pizzas.cuisine.CategoryImpl;

public class PizzShop {
//	public static Pizza gss=new Pizza();
	public static Scanner scannerPizzShop  =new Scanner(System.in);

	public static Pizza pizza=new Pizza();
	
	public static void main(String[]args) {
		
		CuisineImpl sc=new CuisineImpl(); 
		sc.selectCuisine();
		sc.chooseCuisine();
		
		CategoryImpl sv = new CategoryImpl();
		sv.selectVeraity(); 
		sv.ChooseVeraity();
		
		SizeImpl si=new SizeImpl();
		si.ChooseSize();
		
		Toppings tp=new Toppings();
		tp.selectToppings();
		
		Prize pr=new Prize();
		pr.pizzaPrize();
	
		Order or=new Order();
		or.order();
		
	}
}