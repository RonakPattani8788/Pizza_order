package com.pizzas.cuisine;

import com.pizzas.service.Category;
import com.pizzas.service.Size;

public class Prize implements Size,Category {
	public void pizzaPrize(){
		if (Classic_Category.equalsIgnoreCase("Classic")) {
			if (Regular_size.equalsIgnoreCase("Regular-size")) {
		    	  String CR = "135";
		    	  Pizza.setPizza_Prize(CR);
		    }else if (Medium_size.equalsIgnoreCase("You select Medium-size")) {
				String CM = "210";
				Pizza.setPizza_Prize(CM);
			} else if (Large_size.equalsIgnoreCase("Large-Size")) {
				String CL= "360";
				Pizza.setPizza_Prize(CL);
			}
		}
		else if (Premium_Category.equalsIgnoreCase("Premium")) {
			if (Regular_size.equalsIgnoreCase("Regular-size")) {
				String PR = "165";
				Pizza.setPizza_Prize(PR);
			}else if (Medium_size.equalsIgnoreCase("Medium-size")) {
				String PM = "240";
				Pizza.setPizza_Prize(PM);
			}else if (Large_size.equalsIgnoreCase("Large-size")) {
				String PL = "395";
				Pizza.setPizza_Prize(PL);
			}
	    } 
		else if (Supreme_category.equalsIgnoreCase("Supreme")){
			if (Regular_size.equalsIgnoreCase("Regular-size")) {
		   	   String SR = "190";
		   	   Pizza.setPizza_Prize(SR);
		    }else if (Medium_size.equalsIgnoreCase("Medium-size")) {
	    	   String SM = "290";
	    	   Pizza.setPizza_Prize(SM);
		    } else if (Large_size.equalsIgnoreCase("Large-size")) {
		   	   	String SL= "190";
		   	    Pizza.setPizza_Prize(SL);
		    } 
	    }
	}
}
