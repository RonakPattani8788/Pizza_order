package com.pizzas.cuisine;

import java.util.Scanner;

import com.pizzas.PizzShop;
import com.pizzas.cuisine.veraity.ClassicVeraity;
import com.pizzas.cuisine.veraity.PremiumVeraity;
import com.pizzas.cuisine.veraity.SupremeVeraity;
import com.pizzas.service.Category;

public class CategoryImpl implements Category {
	
	public void  selectVeraity() {
		
		System.out.println("-- * Select Veraity  * --");
		System.out.println("1."+Classic_Category);
		System.out.println("2."+Premium_Category);
		System.out.println("3."+Supreme_category);
	}

	public void ChooseVeraity() {
		
//		Pizza pizza = new Pizza();
		int chooseVeraity;
		String Pizza_Veraity;
//		Scanner scanner=new Scanner(System.in);
//		chooseVeraity=scanner.nextInt();
		
		chooseVeraity = PizzShop.scannerPizzShop.nextInt();
		
		if (chooseVeraity == 1) {
			Pizza_Veraity="You select "+Classic_Category;
			ClassicVeraity.Choose_Classic_Veraity();
			Pizza.setCategory_Pizza(Pizza_Veraity);
		} else if (chooseVeraity == 2) {
			Pizza_Veraity="You select "+Premium_Category;
			PremiumVeraity.Choose_Premium_Veraity();
			Pizza.setCategory_Pizza(Pizza_Veraity);
		} else if (chooseVeraity == 3) {
			Pizza_Veraity="You select "+Supreme_category;
			SupremeVeraity.Choose_Supreme_Veraity();
			Pizza.setCategory_Pizza(Pizza_Veraity);
		} else {
			System.out.println("Please Choose Veraity");
		}
		//scanner.close();
	}
}
