package com.pizzas.cuisine.veraity;

import com.pizzas.PizzShop;
import com.pizzas.cuisine.Pizza;
import com.pizzas.service.PizzaMenu;
import com.pizzas.service.Size;

public class ClassicVeraity implements Size, PizzaMenu {
	
	public static void Choose_Classic_Veraity() {
		
		System.out.println("-- * Classic Veraity * --");
		System.out.println("-- Select Pizza --");
		System.out.println("1 :" + Tomchi_Pizza);
		System.out.println("2 :" + Caponito_Pizza);
		Pizza pizza = new Pizza();
		String Classic_Pizza;

		int chooseClassic;
		chooseClassic = PizzShop.scannerPizzShop.nextInt();

		if (chooseClassic == 1) {
			Classic_Pizza = "You are select the " + Tomchi_Pizza;
			System.out.println(Classic_Pizza);
			pizza.setPizzas_Pizza(Classic_Pizza);
		} else if (chooseClassic == 2) {
			Classic_Pizza = "You are select the " + Caponito_Pizza;
			System.out.println(Classic_Pizza);
			pizza.setPizzas_Pizza(Classic_Pizza);
		} else {
			System.out.println("Please Choose Veraity");
		}
	}
}
