package com.pizzas.cuisine.veraity;

import java.util.Scanner;

import com.pizzas.PizzShop;
import com.pizzas.cuisine.Pizza;
import com.pizzas.service.PizzaMenu;
import com.pizzas.service.Size;

public class PremiumVeraity implements Size,PizzaMenu {
		
	public static void Choose_Premium_Veraity(){
		System.out.println("-- * Premium Veraity * --");
		System.out.println("-- Select Pizza --");
		System.out.println("1 :"+Red_Indian_Pizza);
		System.out.println("2 :"+Party_Lovers_Pizza);
		
		Pizza pizza = new Pizza();
		String Premium_Pizza;
		
		int choosePremium;
		choosePremium=PizzShop.scannerPizzShop.nextInt();
		if(choosePremium==1) {
			Premium_Pizza="You select"+Red_Indian_Pizza;
			System.out.println(Premium_Pizza);
			pizza.setPizzas_Pizza(Premium_Pizza);
		}
		else if(choosePremium==2) {
			Premium_Pizza="You select"+Party_Lovers_Pizza;
			System.out.println(Premium_Pizza);
			pizza.setPizzas_Pizza(Premium_Pizza);
		}
		else {
			System.out.println("Please Choose Veraity");
		}
		//scanner.close();
	}
}
