package com.pizzas.cuisine.veraity;

import java.util.ArrayList;
import java.util.Scanner;

import com.pizzas.PizzShop;
import com.pizzas.cuisine.Pizza;
import com.pizzas.service.PizzaMenu;
import com.pizzas.service.Size;

public class SupremeVeraity implements Size,PizzaMenu {
	
	public static void Choose_Supreme_Veraity(){
		System.out.println("-- * Supreme Veraity * --");
		System.out.println("-- Select Pizza --");
		System.out.println("1 :"+American_Heat_Pizza);
		System.out.println("2 :"+Re_Union_Pizza);
		
		Pizza pizza = new Pizza();
		String Supreme_Pizza;
		
		int chooseSupreme;
		chooseSupreme=PizzShop.scannerPizzShop.nextInt();
		
		if(chooseSupreme==1) {
			Supreme_Pizza="You select"+American_Heat_Pizza;
			System.out.println(Supreme_Pizza);
			pizza.setPizzas_Pizza(Supreme_Pizza);
		}
		else if(chooseSupreme==2) {
			Supreme_Pizza="You select"+Re_Union_Pizza;
			System.out.println(Supreme_Pizza);
			pizza.setPizzas_Pizza(Supreme_Pizza);
		}
		else {
			System.out.println("Please Choose Veraity");
		}
	}
}
