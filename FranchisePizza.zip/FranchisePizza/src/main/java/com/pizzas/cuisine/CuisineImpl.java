package com.pizzas.cuisine;

import java.util.Scanner;

import com.pizzas.PizzShop;
import com.pizzas.service.Cuisine;

public class CuisineImpl implements Cuisine 
{
	public void  selectCuisine()
	{
		System.out.println("---- ** Welcome to my Pizza Shop ** ----");
		System.out.println("-- * Select Cuisine * --");
		System.out.println("1 :"+Regular_Cuisine);
		System.out.println("2 :"+Jain_Cuisine);
		System.out.println("3 :"+Non_Veg_Cuisine);
	}
	
	public void chooseCuisine() 
	{
//		Pizza pizza = new Pizza();
//		Scanner scanner=new Scanner(System.in);
//		chooseCuisine=scanner.nextInt();
		int chooseCuisine;
		String Cuisine;
		
		chooseCuisine=PizzShop.scannerPizzShop.nextInt();
		
		if(chooseCuisine==1) {
			Cuisine="You are select the "+Regular_Cuisine;
			System.out.println(Cuisine);
//			pizza.setCuisine_Pizza(Cuisine);
			Pizza.setCuisine_Pizza(Cuisine);
			
		}
		else if(chooseCuisine==2) {
			Cuisine="You are select the "+Jain_Cuisine;
			System.out.println(Cuisine);
//			pizza.setCuisine_Pizza(Cuisine);
			Pizza.setCuisine_Pizza(Cuisine);
		}
		else if(chooseCuisine==3) {
			Cuisine="You are select the "+Non_Veg_Cuisine;
			System.out.println(Cuisine);
//			pizza.setCuisine_Pizza(Cuisine);
			Pizza.setCuisine_Pizza(Cuisine);
		}
		else {
			System.out.println("Please Choose Cuisine");
		}
		//scanner.close();
	}
	
}
