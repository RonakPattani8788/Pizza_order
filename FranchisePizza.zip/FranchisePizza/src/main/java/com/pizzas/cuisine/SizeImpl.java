package com.pizzas.cuisine;

import com.pizzas.PizzShop;
import com.pizzas.service.Size;

public class SizeImpl implements Size {
	
	public void ChooseSize() {
		System.out.println("-- * Select Size * --");
		System.out.println("1." + Regular_size);
		System.out.println("2."+ Medium_size);
		System.out.println("3."+ Large_size);
		
		Pizza pizza = new Pizza();
		String Pizza_Size;
		int chooseSize;
//		Scanner scanner=new Scanner(System.in);
//		chooseSize=scanner.nextInt();
		
		chooseSize = PizzShop.scannerPizzShop.nextInt();
		
		if(chooseSize==1) {
			Pizza_Size="You select "+Regular_size;
			System.out.println(Pizza_Size);
			pizza.setSize_Pizza(Pizza_Size);
		}
		else if(chooseSize==2) {
			Pizza_Size="You select "+Medium_size;
			System.out.println(Pizza_Size);
			pizza.setSize_Pizza(Pizza_Size);
		}
		else if(chooseSize==3) {
			Pizza_Size="You select "+Medium_size;
			System.out.println(Pizza_Size);
			pizza.setSize_Pizza(Pizza_Size);
		}
		else {
			System.out.println("Please Choose Veraity");
		}
	//	scanner.close();
	}
}
