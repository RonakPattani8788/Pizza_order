package com.pizzas.cuisine;

import com.pizzas.PizzShop;
import com.pizzas.cuisine.Pizza;
import com.pizzas.service.PizzaMenu;

public class Toppings extends Pizza implements PizzaMenu {

	public void selectToppings() {
		
		int toppings;
		String ToppingPizza;
		if (Tomchi_Pizza.equalsIgnoreCase("Tomchi")) {
			System.out.println("-- * Select tomchi Toppings * --");
			System.out.println("1. Tomato");
			System.out.println("2. Onion");
			System.out.println("3. Chilly and Cheese");
			toppings = PizzShop.scannerPizzShop.nextInt();
			if (toppings == 1) {
				String tomato = "You select Tomato";
				System.out.println(tomato);
				Pizza.setToppings_Pizza(tomato);
			} else if (toppings == 2) {
				String onion = "You select Onion";
				System.out.println(onion);
				Pizza.setToppings_Pizza(onion);
			} else if (toppings == 3) {
				String Chilly_and_Cheese = "You select Chilly and Cheese";
				System.out.println(Chilly_and_Cheese);
				Pizza.setToppings_Pizza(Chilly_and_Cheese);
			} else {
				System.out.println("Please Enter toppings");
			}
		} else if (Caponito_Pizza.equalsIgnoreCase("Caponito")) {
			System.out.println("-- * Select Caponito Toppings * --");
			System.out.println("1. Capsicum");
			System.out.println("2. Onion");
			System.out.println("3. Cheese and Tomato");
			toppings = PizzShop.scannerPizzShop.nextInt();
			if (toppings == 1) {
				String capsicum = "You select Capsicum";
				System.out.println(capsicum);
				Pizza.setToppings_Pizza(capsicum);
			} else if (toppings == 2) {
				String onion = "You select Onion";
				System.out.println(onion);
				Pizza.setToppings_Pizza(onion);
			} else if (toppings == 3) {
				String Cheese_and_Tomato = "You select Cheese and Tomato";
				System.out.println(Cheese_and_Tomato);
				Pizza.setToppings_Pizza(Cheese_and_Tomato);
			} else {
				System.out.println("Please Enter toppings");
			}
		} else if (Red_Indian_Pizza.equalsIgnoreCase("Red_Indian")) {
			System.out.println("-- * Select Red Indian Toppings * --");
			System.out.println("1. Cheese");
			System.out.println("2. Paneer");
			System.out.println("3. Chilly");
			toppings = PizzShop.scannerPizzShop.nextInt();
			if (toppings == 1) {
				String cheese = "You select Cheese";
				System.out.println(cheese);
				Pizza.setToppings_Pizza(cheese);
			} else if (toppings == 2) {
				String paneer = "You select Paneer";
				System.out.println(paneer);
				Pizza.setToppings_Pizza(paneer);
			} else if (toppings == 3) {
				String chilly = "You select Chilly";
				System.out.println(chilly);
				Pizza.setToppings_Pizza(chilly);
			} else {
				System.out.println("Please Enter toppings");
			}
		} else if (Party_Lovers_Pizza.equalsIgnoreCase("Party_Lovers")) {
			System.out.println("-- * Select Party Lovers Toppings * --");
			System.out.println("1. Cheese");
			System.out.println("2. Sweet Corn");
			System.out.println("3. Capsicum");
			System.out.println("4. Tomato");
			toppings = PizzShop.scannerPizzShop.nextInt();
			if (toppings == 1) {
				String cheese = "You select Cheese";
				System.out.println(cheese);
				Pizza.setToppings_Pizza(cheese);
			} else if (toppings == 2) {
				String seet_corn = "You select Sweet Corn";
				System.out.println(seet_corn);
				Pizza.setToppings_Pizza(seet_corn);
			} else if (toppings == 3) {
				String capsicum = "You select Capsicum";
				System.out.println(capsicum);
				Pizza.setToppings_Pizza(capsicum);
			} else if (toppings == 3) {
				String tomato = "You select Tomato";
				System.out.println(tomato);
				Pizza.setToppings_Pizza(tomato);
			} else {
				System.out.println("Please Enter toppings");
			}
		}else if (American_Heat_Pizza.equalsIgnoreCase("Party_Lovers")) {
			System.out.println("-- * Select Party Lovers Toppings * --");
			System.out.println("1. Cheese");
			System.out.println("2. Baby Corn");
			System.out.println("3. Capsicum");
			toppings = PizzShop.scannerPizzShop.nextInt();
			if (toppings == 1) {
				String cheese = "You select Cheese";
				System.out.println(cheese);
				Pizza.setToppings_Pizza(cheese);
			} else if (toppings == 2) {
				String baby_corn = "You select Baby Corn";
				System.out.println(baby_corn);
				Pizza.setToppings_Pizza(baby_corn);
			} else if (toppings == 3) {
				String capsicum = "You select Capsicum";
				System.out.println(capsicum);
				Pizza.setToppings_Pizza(capsicum);
			} else {
				System.out.println("Please Enter toppings");
			}
		}else if (Re_Union_Pizza.equalsIgnoreCase("Party_Lovers")) {
			System.out.println("-- * Select Party Lovers Toppings * --");
			System.out.println("1. Cheese");
			System.out.println("2. Baby Corn");
			System.out.println("3. Capsicum");
			System.out.println("4. Spinach");
			System.out.println("5. Olives");
			toppings = PizzShop.scannerPizzShop.nextInt();
			if (toppings == 1) {
				String cheese = "You select Cheese";
				System.out.println(cheese);
				Pizza.setToppings_Pizza(cheese);
			} else if (toppings == 2) {
				String baby_corn = "You select Baby Corn";
				System.out.println(baby_corn);
				Pizza.setToppings_Pizza(baby_corn);
			} else if (toppings == 3) {
				String capsicum = "You select Capsicum";
				System.out.println(capsicum);
				Pizza.setToppings_Pizza(capsicum);
			}else if (toppings == 4) {
				String Spinach = "You select Spinach";
				System.out.println(Spinach);
				Pizza.setToppings_Pizza(Spinach);
			}else if (toppings == 3) {
				String Olives = "You select Olives";
				System.out.println(Olives);
				Pizza.setToppings_Pizza(Olives);
			} else {
				System.out.println("Please Enter toppings");
			}
		}else {
			System.out.println("Please Choose Toppings.");
		}
	}
}
