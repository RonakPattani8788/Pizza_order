package com.pizzas.cuisine;

public class Order extends Pizza{
	public void order() {
			
			System.out.println("-- * Your Order * --");
			System.out.println("Cuisine  : "+Pizza.getCuisine_Pizza());
			System.out.println("Category : "+Pizza.getCategory_Pizza());
			System.out.println("Size     : "+Pizza.getSize_Pizza());
			System.out.println("Pizzas   : "+Pizza.getPizzas_Pizza());
			System.out.println("Toppings : "+Pizza.getToppings_Pizza());
			System.out.println("Prize    : "+Pizza.getPizza_Prize());
        }
    }
