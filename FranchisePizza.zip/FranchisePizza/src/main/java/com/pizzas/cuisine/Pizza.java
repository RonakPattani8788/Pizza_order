package com.pizzas.cuisine;

import com.pizzas.service.Category;
import com.pizzas.service.Cuisine;
import com.pizzas.service.PizzaMenu;
import com.pizzas.service.Size;

public class Pizza implements Category,Cuisine,PizzaMenu,Size {

	// Select Cuisine
	private static String Cuisine_Pizza;
	private static String Category_Pizza;
	private static String Size_Pizza;
	private static String Pizzas_Pizza;
	private static String Toppings_Pizza;
	private static String Prize_Pizza;
	
	public static void setCuisine_Pizza(String C_Pizza) {
		Cuisine_Pizza=C_Pizza;
	}
	
	public static String getCuisine_Pizza() {
		return Cuisine_Pizza;
	}
	
	//Pizza Category 
	public static void setCategory_Pizza(String Cat_Pizza) {
		Category_Pizza=Cat_Pizza;
	}
	
	public static String getCategory_Pizza() {
		return Category_Pizza;
	}
	
	//Pizza Size
	public static void setSize_Pizza(String S_Pizza) {
		Size_Pizza=S_Pizza;
	}
		
	public static String getSize_Pizza() {
		return Size_Pizza;
	}
	
	// Select Pizza
	public static void setPizzas_Pizza(String P_Pizza) {
		Pizzas_Pizza=P_Pizza;
	}
			
	public static String getPizzas_Pizza() {
		return Pizzas_Pizza;
	}
	
	// Toppings Pizza
	public static void setToppings_Pizza(String T_Pizza) {
		Toppings_Pizza=T_Pizza;
	}
			
	public static String getToppings_Pizza() {
		return Toppings_Pizza;
	}
	
    //    pizza_prize;
    public static void setPizza_Prize(String p_prize) {
//    	p_prize="AAA";
    	Prize_Pizza=p_prize;
    }
    public static String getPizza_Prize() {
    	return Prize_Pizza;
    }
}